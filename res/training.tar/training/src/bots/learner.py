from src.bots.bot import Bot

def freshStratArr():
    a=[]
    for i in range(14):
        a.append("2")
    return a

class LearnBot(Bot):

    def __init__(self):
        super().__init__("Bot", freshStratArr(), freshStratArr(), freshStratArr(), freshStratArr())